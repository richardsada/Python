from lab_4_base_class import Product
from lab_4_size import Size

eggs = Product(100, 8, 6, 4)
print("Цена товара со скидкой")
print(eggs.discount(50))
print(eggs.__str__())

class iskl(Exception):
    pass

try:
    c = int(input("Введите цену товара: "))
    pie = Product(c, 10, 15, 40)
    d = int(input("Введите скидку на  товар: "))
    if d >= 100:
        raise iskl
    print("Цена товара со скидкой" , pie.discount(d))
    
except iskl:
    print("Скидка не должна превышать 100 %")
except Exception as e:
    print(e)

print("Количество упаковок в транспортировочной коробке: ")
egg = Size(200, 8, 6, 4)
count = egg.counts_in_box(16, 36, 8)
print(count)
try:
    pie = Size(100, 4, 3, 2)
    a = int(input("Введите длину транспортировочной коробки: "))
    b = int(input("Введите ширину транспортировочной коробки: "))
    h = int(input("Введите высоту транспортировочной коробки: "))
    print("Количество упаковок в транспортировочной коробке: ")
    print(pie.counts_in_box(a, b, h))
except:
    print("Недопустимое значение параметров коробки")

