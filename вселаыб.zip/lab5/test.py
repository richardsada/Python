from lab_4_base_class import Product  
from lab_4_size import Sizeble
milk = Product(200, 3, 2, 1,"milk")
#milk.write_to_file("test")
milk1 = Product(100, 1, 1, 1,"milk1")
milk1 = Product.read_from_file("test")
print(milk1)