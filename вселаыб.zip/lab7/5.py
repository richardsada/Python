import aiohttp
import asyncio

async def fetch_status(url: str):
    """
    Выполняет асинхронный HTTP-запрос и возвращает статус ответа,
    обрабатывая возможные исключения.

    :param url: URL для запроса.
    """
    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(url, timeout=10) as response:  # Устанавливаем таймаут
                print(f"Запрос к {url} вернул статус: {response.status}")
                return response.status
        except aiohttp.ClientError as e:
            print(f"Сетевая ошибка при запросе к {url}: {e}")
        except asyncio.TimeoutError:
            print(f"Превышено время ожидания для {url}")
        except Exception as e:
            print(f"Непредвиденная ошибка при запросе к {url}: {e}")

async def main():
    urls = [
        "https://www.google.com",
        "https://www.discord.org",
        "https://www.github.com",
        "https://www.youtube.com",
        "https://www.invalid-url",  # Неверный URL
        "https://www.github.com",
        "https://nonexistent.website",  # Несуществующий домен
    ]
    tasks = [fetch_status(url) for url in urls]
    await asyncio.gather(*tasks)  # Выполняем задачи одновременно


asyncio.run(main())
