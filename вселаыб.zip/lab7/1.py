import aiofiles

async def read_file_async(file_path: str) -> str:

    async with aiofiles.open(file_path, mode='r', encoding='utf-8') as file:
        content = await file.read() # Асинхронное чтение всего содержимого файла.
    return content

import asyncio

async def main():
    file_content = await read_file_async('example.txt')
    print(file_content)


asyncio.run(main())
