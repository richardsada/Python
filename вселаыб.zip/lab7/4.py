import aiohttp
import asyncio

async def fetch_status(url: str):
 
    async with aiohttp.ClientSession() as session:
        async with session.get(url) as response:
            print(f"Запрос к {url} вернул статус: {response.status}")
            return response.status

async def main():
    urls = [
        "https://www.google.com",
        "https://www.discord.org",
        "https://www.github.com",
        "https://www.youtube.com",
        
    ]
    tasks = [fetch_status(url) for url in urls]  # Создаем задачи для каждого URL
    await asyncio.gather(*tasks)  # Выполняем задачи одновременно


asyncio.run(main())
