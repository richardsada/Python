import os
import time
from imaplib import IMAP4_SSL
import email
from email.header import decode_header
from dotenv import load_dotenv
load_dotenv()

EMAIL_LOGIN = os.getenv("EMAIL_LOGIN") # Email логин администратора
EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD") #Email пароль администратора
PERIOD_CHECK = int(os.getenv("PERIOD_CHECK")) #Частота проверки новых сообщений (в секундах)
IMAP_HOST = os.getenv("IMAP_HOST") #Хост почтового сервера (чтение сообщений)
IMAP_PORT = int(os.getenv("IMAP_PORT")) #Порт почтового сервера (чтение сообщений)


def checkout():
    with IMAP4_SSL(IMAP_HOST, IMAP_PORT) as M:
        M.login(EMAIL_LOGIN, EMAIL_PASSWORD)
        M.select()
        _, data = M.search(None, "UNSEEN")
        print(data[0].split())
        for num in data[0].split():
            _, data = M.fetch(num, '(RFC822)')
            msg = email.message_from_bytes(data[0][1])
            try:
                header = decode_header(msg["Subject"])[0][0].decode()
            except AttributeError:
                header = decode_header(msg["Subject"])[0][0]
            #print(header)
            if msg.is_multipart():
                for part in msg.get_payload():
                    if part.get_content_type() == "text/plain":
                        message_text = part.get_payload(decode=True).decode()
                        break
            else:
                message_text = msg.get_payload(decode=True).decode()
            if "[Ticket #" not in header or "] Mailer" not in header:
                with open("error_request.log", "a", encoding="utf-8") as error_file:
                    error_file.write(f"Text: {message_text}\n")
                    print("В файл error_request.log была добавлена запись.")
            else:
                with open("success_request.log", "a", encoding="utf-8") as success_file:
                    success_file.write(f"ID: {msg['Message-ID']}\n")
                    success_file.write(f"Text: {message_text}\n")
                    print("В файл success_request.log была добавлена запись.")


while True:
    checkout()
    time.sleep(PERIOD_CHECK)

