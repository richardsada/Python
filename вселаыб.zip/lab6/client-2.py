import socket
import pickle


def client_data(email, message):
    while True:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            host = '127.0.0.1'
            port = 6789
            s.connect((host, port))

            if email == "" or message == "":
                print("Нет email или сообщение")

            binary_representation_of_a_message = pickle.dumps(f"{email},{message}")
            s.sendall(binary_representation_of_a_message)
            data = s.recv(1024)

            if repr(data) == "OK":
                print("Письмо отправлено")
                break


email = input("Введите email: ")
message = input("Введите сообщение: ")
client_data(email, message)