import socket
from smtplib import SMTP
import os
import pickle
from random import randint
from dotenv import load_dotenv
from email.mime.text import MIMEText



load_dotenv()
EMAIL_LOGIN = os.getenv("EMAIL_LOGIN")
EMAIL_PASSWORD = os.getenv("EMAIL_PASSWORD")
PERIOD_CHECK = os.getenv("PERIOD_CHECK")
SMTP_HOST = os.getenv("SMTP_HOST")
SMTP_PORT = int(os.getenv("SMTP_PORT", 587))  # 587 — значение по умолчанию


def send_email(admin_login, new_email, msg):
    with SMTP(str(SMTP_HOST), SMTP_PORT) as smtp:
        smtp.starttls()
        subject = f"[Ticket #{randint(11111, 99999)}] Mailer\n"
        smtp.login(str(admin_login), str(EMAIL_PASSWORD))
        smtp.sendmail(str(admin_login), new_email, f"Subject: {subject}{MIMEText(msg)}")
        smtp.sendmail(str(admin_login), str(admin_login), f"Subject: {subject}{MIMEText(msg)}")
        smtp.quit()


host = '127.0.0.1'
port = 6789
with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
    s.bind((host, port))
    s.listen(2)
    while True:
        client_socket, client_address = s.accept()
        print(f'Получено соединение от {client_address}')
        with client_socket:
            email, message = pickle.loads(client_socket.recv(1024)).split(',')
            print(email, message)
            if not email:
                client_socket.sendall(bytes("Нет электронной почты", "UTF-8"))
            if not message:
                client_socket.sendall(bytes("Нет сообщения", "UTF-8"))
            else:
                if "@" not in email or "." not in email:
                    client_socket.sendall(bytes("Некорректный email", "UTF-8"))
                else:
                    try:
                        send_email(EMAIL_LOGIN, email, message)
                        client_socket.sendall(b"OK")
                        print("Отправлено")
                        break
                    except Exception as e:
                        error_message = f"Ошибка отправки письма: {str(e)}"
                        client_socket.send(error_message.encode())